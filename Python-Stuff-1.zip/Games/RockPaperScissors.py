a = "1"
b = input()
if (a == b):
  print("Hello this works")
elif (a < b):
  print("This is not working")
elif (a > b):
  print("Works")